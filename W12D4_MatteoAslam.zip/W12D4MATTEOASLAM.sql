drop schema if exists toys_group;

-- creo e nomino il db

create schema toys_group;

-- specifico l'utilizzo di questo db

use toys_group;

-- creo le cartelle e inserisco i dati

create table category (
category_id int auto_increment not null primary key,
name varchar(50) not null
);

insert into category(name) value
('Giochi di costruzione'),
  ('Bambole'),
  ('Giochi di ruolo'),
  ('Giochi di società'),
  ('Giochi di abilità'),
  ('Libri'),
  ('Materiale scolastico'),
  ('Modellini');
  

create table product(
product_id int auto_increment not null primary key,
name varchar(50) not null,
description varchar(100) not null,
category_id int not null,
quantity_total int not null,
price int not null,
foreign key (category_id) references category(category_id)
);

insert into product(name,description,category_id,quantity_total,price) value
('Lego', 'Set di costruzioni per bambini con 100 pezzi', 1,100,40.00),
  ('Barbie', 'Bambola fashion con vestiti e accessori',2,100,30.00),
  ('Saetta McQueen', 'Macchinina telecomandata con velocità fino a 20 km/h',8,200,60.00),
  ('Grezzodue', 'Gioco da tavolo per 2-4 giocatori', 4,100,25.00),
  ('Monalisa:il puzzle','Puzzle da 1000 pezzi con paesaggi mozzafiato', 5,100,15.00),
  ('Geronimo Stilton', 'Libro per bambini con favole illustrate', 6,100,20.00),
  ('Matite Faber Castell',  'Matite colorate con 12 colori',7,500,10.00),
  ('Quaderno', 'Quaderno a righe con copertina rigida',7,300,4.00),
  ('Pennarelli', 'Pennarelli a punta fine con 10 colori',7,400,20.00),
  ('Forbici', 'Forbici per carta con lame in acciaio inossidabile',7,200,3.00),
  ('Bearbrick', 'Statuetta in vinile',8,100, 150.00),
  ('Bambola Barbara', 'Bambola fashion con vestiti', 2,500, 250.00)
  ;
 
create table region(
region_id int auto_increment not null primary key,
name varchar(50) not null
);

 insert into region(name) value
 ('Europa occidentale'),
  ('Europa meridionale'),
  ('America settentrionale'),
  ('America meridionale'),
  ('Asia'),
  ('Africa'),
  ('Oceania'),
  ('Asia orientale'),
  ('Asia sudorientale'),
  ('Asia centrale');

create table nation(
nation_id int auto_increment not null primary key,
name varchar(50) not null,
region_id int not null,
foreign key (region_id) references region(region_id)
);

insert into nation(name,region_id) value
    ('Italia', 1),
  ('Francia', 1),
  ('Germania', 1),
  ('Spagna', 2),
  ('Brasile', 4),
  ('Argentina', 4),
  ('Cina', 6),
  ('Giappone', 6),
  ('Stati Uniti', 3),
  ('Canada', 3);
  
  
  
-- inseriti i dati tramite table wizard da sales.csv nella cartella allegata e faccio la dichiarazione delle chiavi e del tipo di dato

alter table sales
rename column `ï»¿sales_id` to sales_id;
ALTER TABLE sales ADD PRIMARY KEY (sales_id);
ALTER TABLE sales MODIFY product_id INT NOT NULL;
ALTER TABLE sales MODIFY region_id INT NOT NULL;
ALTER TABLE sales MODIFY orderdate DATE NOT NULL;
ALTER TABLE sales modify quantity_selled INT NOT NULL;
ALTER TABLE sales
ADD FOREIGN KEY (product_id)
REFERENCES product(product_id);
ALTER TABLE sales
ADD FOREIGN KEY (region_id)
REFERENCES region(region_id);



-- Verificare che i campi definiti come PK siano univoci. 

desc category;
desc nation;
desc product;
desc region;
desc sales;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

select p.name, year(s.orderdate) as anno, sum(p.price * s.quantity_selled) as fatturato_tot
from sales as s
join product as p
on p.product_id = s.product_id
group by p.name, anno
order by anno desc, fatturato_tot desc;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

select n.name as nazione, year(s.orderdate) as anno, sum(p.price * s.quantity_selled) as fatturato_tot
from sales as s
join product as p
on p.product_id=s.product_id
join region as r
on s.region_id=r.region_id
join nation as n
on n.region_id=r.region_id
group by nazione, anno
order by anno desc, fatturato_tot desc;

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

select c.name, sum(s.quantity_selled * p.price) as tot
from product p
join category c 
on c.category_id=p.category_id
join sales s 
on s.product_id = p.product_id
group by c.name
order by tot desc
limit 1;

  
  -- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
  
select distinct p.name from product p
join sales s
on s.product_id = p.product_id
where s.quantity_selled = 1; -- ci dice i prodotti venduti almeno una volta

SELECT p.name
FROM product p
WHERE NOT EXISTS (
  SELECT 1
  FROM sales s
  WHERE s.product_id = p.product_id
  AND s.quantity_selled > 0
); -- ci dice i prodotti se ci sono vendite con quantità maggiore di 0 per ogni prodotto, se non ci sono ci darà il nome del prodotto

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select p.product_id, p.name, s.orderdate
from product p, sales s 
group by p.product_id,p.name, s.orderdate
order by s.orderdate desc
limit 12;

-- traccia bonus

select s.sales_id, s.orderdate, p.name, c.name, n.name, r.name, CASE
    WHEN DATEDIFF(CURRENT_DATE(), s.orderdate) > 180 THEN TRUE
    ELSE FALSE
  END AS piu_di_180_giorni
  from sales s
  join product p on s.product_id = p.product_id
  join category c on p.category_id = c.category_id
  join region r on r.region_id=s.region_id
  join nation n on n.region_id=r.region_id;

