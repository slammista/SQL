create schema GESTIONALE;

USE GESTIONALE;

create table prodotto (id_prodotto int primary key,
nome_prodotto varchar(100),
prezzo decimal (10,2)
);

create table cliente (id_cliente int primary key,
nome_cliente varchar(50),
email varchar (100)
);

create table ordine (id_ordine int primary key,
id_prodotto int,
id_cliente int,
quantita int,
foreign key (id_prodotto) references prodotto(id_prodotto),
foreign key (id_cliente) references cliente(id_cliente)
);


insert into prodotto(id_prodotto, nome_prodotto, prezzo) values
(1, 'Tablet','300.00'),
(2, 'Mouse', '20.00'),
(3, 'Tastiera', '25.00'),
(4, 'Monitor', '180.00'),
(5, 'HHD','90.00'),
(6, 'SSD','200.00'),
(7, 'RAM','100.00'),
(8, 'Router','80.00'),
(9, 'Webcam','45.00'),
(10, 'GPU','1250.00'),
(11, 'Trackpad','500.00'),
(12, 'Techmagazine','5.00'),
(13, 'Martech','50.00');



Insert into cliente(id_cliente,nome_cliente,email) values
(1, 'Antonio', NULL),
(2, 'Battista', 'battista@mailmail.it'),
(3, 'Ettore', NULL),
(4, 'Franca', 'franca@lettere.it'),
(5, 'Maria', 'maria@posta.it'),
(6, 'Piero', 'piero@lavoro.it'),
(7, 'Arianna', 'arianna@posta.it');



insert into ordine (id_ordine, id_prodotto, id_cliente, quantita) values
(1, 2, 1, 10),
(2, 6, 2, 2),
(3, 5, 3, 3),
(4, 1, 4, 1),
(5, 9, 5, 1),
(6, 4, 6,2),
(7, 11, 7, 6),
(8, 10, 1, 2),
(9, 3, 7, 3),
(10, 3, 3, 1),
(11, 2, 2, 1);

create table dettaglio_ordine (id_ordine int,
id_prodotto int,
id_cliente int,
prezzo_totale float,
primary key (id_ordine, id_prodotto, id_cliente),
foreign key(id_ordine)references ordine(id_ordine),
foreign key (id_prodotto)references prodotto (id_prodotto),
foreign key (id_cliente) references cliente(id_cliente)
);

insert into dettaglio_ordine(id_ordine, id_prodotto, id_cliente, prezzo_totale) select 
ord.id_ordine,
ord.id_prodotto,
ord.id_cliente,
prod.prezzo * ord.quantita as prezzo_totale
from ordine ord, prodotto prod
where ord.id_prodotto = prod.id_prodotto;

select * from dettaglio_ordine;





