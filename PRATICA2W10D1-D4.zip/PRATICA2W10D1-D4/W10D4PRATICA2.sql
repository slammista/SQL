-- 1 seleziona tutti i prodotti con prezzo superiore a 50 euro

select * from prodotto
where prezzo > '50.00';

-- 2 seleziona tutte le email dei clienti il cui nome inizia con A nella tabella clienti

select email from cliente
where nome_cliente like 'A%';

-- 3 seleziona tutti gli ordini con una quantità maggiore di 10 o con un importo totale inferiore a 100 euro dalla tabella Ordini
select o.quantita, dett.prezzo_totale, dett.id_ordine from dettaglio_ordine dett, ordine o
inner join dettaglio_ordine on dettaglio_ordine.id_ordine = o.id_ordine
where o.quantita > 10 or dett.prezzo_totale < 100

-- 4 Seleziona tutti i prezzi dei prodotti il cui nome contiene la parola 'tech' indipendentemente dalla posizione nella tabella Prodotti
select * from prodotto
where nome_prodotto like '%tech%';



-- 5 Seleziona tutti i clienti che non hanno un indirizzo email nella tabella Clienti.
select * from cliente
where email is null

-- 6 Seleziona tutti i prodotti il cui nome inizia con 'M' e termina con 'e' indipendentemente dalla lunghezza della parola nella tabella Prodotti.
select * from prodotto
where nome_prodotto like 'M%e';


