-- Fate un elenco di tutte le tabelle.
use chinook;
show tables;

-- Visualizzate le prime 10 righe della tabella Album.

select * from album
limit 10;

-- Trovate il numero totale di canzoni della tabella Tracks.

select count(trackid) as numero_canzoni from track;

-- Trovate i diversi generi presenti nella tabella Genre

select count(genreid) as numero_generi from genre;

-- ESERCIZIO 2
-- Recuperate il nome di tutte le tracce e del genere associato.

SELECT genre.Name AS genre_name, track.Name
FROM track
JOIN genre ON track.genreid = genre.GenreId;

-- 3 Recuperate il nome di tutti gli artisti che hanno almeno un album nel database. 
-- Esistono artisti senza album nel database?

select * from album;

select distinct artist.name as artist_name
from album
join artist on album.artistid = artist.ArtistId;

SELECT COUNT(DISTINCT artist.artistid) AS artist_count,
       COUNT(*) AS album_count
FROM artist
LEFT JOIN album ON artist.artistid = album.artistid;

-- Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media. 
-- Esiste un modo per recuperare il nome della tipologia di media?

select * from track;


SELECT genre.Name AS genre_name, track.Name, track.mediatypeid, mediatype.name
FROM track
JOIN genre ON track.genreid = genre.GenreId
join mediatype on track.mediatypeid = mediatype.mediatypeid;

-- Elencate i nomi di tutti gli artisti e dei loro album.

select artist.name, album.title  
from artist
join album
on artist.artistid = album.artistid;

