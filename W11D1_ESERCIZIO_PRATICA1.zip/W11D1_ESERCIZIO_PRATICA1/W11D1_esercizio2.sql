-- Recuperate tutte le tracce che abbiano come genere “Pop” o “Rock”.

select track.name, genre.Name from track
join genre
on genre.GenreId = track.GenreId
where genre.name = 'pop' or 'rock';

-- Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”.

select album.title, artist.name from album
join artist
on album.artistid = artist.artistid
where album.title like 'A%'

-- Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti

