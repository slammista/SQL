-- Recuperate tutte le tracce che abbiano come genere “Pop” o “Rock”.
use chinook;

select track.name, genre.Name from track
join genre
on genre.GenreId = track.GenreId
where genre.name = 'pop' or 'rock';

-- Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”.

select album.title, artist.name from album
join artist
on album.artistid = artist.artistid
where album.title like 'A%';


-- Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti

UPDATE track
SET milliseconds = SEC_TO_TIME(milliseconds * 1000);

UPDATE track
SET milliseconds = DATE_FORMAT(milliseconds / 1000, '%i:%s');




select track.name,floor(track.milliseconds/1000)/60 as minuti, genre.name from track
join genre
on genre.GenreId=track.genreid
where genre.name = 'Jazz' or track.Milliseconds < '3';


-- Recuperate tutte le tracce più lunghe della durata media.

select name, milliseconds from track
where milliseconds > (select avg (milliseconds) from track);


-- Individuate i generi che hanno tracce con una durata media maggiore di 4 minuti.

select t.TrackId, t.name, g.name, avg(floor(t.milliseconds/1000)/60) as minuti_medi
from track as t
join genre as g
on t.GenreId = g.GenreId
where t.milliseconds > (4*1000)*60
group by t.trackid;

-- Individuate gli artisti che hanno rilasciato più di un album.

select artist.ArtistId, artist.Name, count(album.AlbumId) as n_album from album
join artist
on album.ArtistId = artist.ArtistId
group by artist.ArtistId, artist.Name
having n_album >= 2;



-- Trovate la traccia più lunga in ogni album.
select count(albumid) from album

-- gli album sono 347, facendo un max
select * from mediatype

SELECT a.Title, t.Name, t.milliseconds AS Durata
FROM Album a
INNER JOIN Track t ON a.AlbumId = t.AlbumId
inner join mediatype m on m.mediatypeid = t.mediatypeid
where t.milliseconds in (
select max(t.milliseconds) 
from track t
group by albumid
)
and m.name <> 'Protected MPEG-4 video file'  -- escludo file che non siano file audio
order by t.milliseconds desc
limit 347;

-- Individuate la durata media delle tracce per ogni album.


SELECT t.name, a.Title, AVG(t.Milliseconds) AS DurataMedia
FROM Album a
INNER JOIN Track t ON a.AlbumId = t.AlbumId
inner join mediatype m on m.mediatypeid = t.mediatypeid
where m.name <> 'Protected MPEG-4 video file'  -- escludo file che non siano file audio
GROUP BY t.name, a.title
ORDER BY a.title;


-- Individuate gli album che hanno più di 20 tracce e mostrate il nome dell’album e il numero di tracce in esso contenute.

select a.title, count(a.AlbumId) as n_tracce from album a
join track t on t.AlbumId=a.albumid
inner join mediatype m on m.mediatypeid = t.mediatypeid
where m.name <> 'Protected MPEG-4 video file'
group by a.title
having n_tracce > 20
order by a.title;
