use chinook;

-- Elencate il numero di tracce per ogni genere in ordine discendente, escludendo quei generi che hanno meno di 10 tracce.

select g.name, count(t.trackid) as n_track from track t
join genre g
on g.GenreId=t.genreid
group by g.name
having n_track  >=10
order by n_track desc;

-- Trovate le tre canzoni più costose

select t.name, i.total from invoiceline il
join invoice i
on i.InvoiceId=il.InvoiceId
join track t
on il.TrackId=t.TrackId
order by i.total desc
limit 3;

-- Elencate gli artisti che hanno canzoni più lunghe di 6 minuti.
select * from artist;
select * from album;
select* from track;

select art.name, TIME_FORMAT(SEC_TO_TIME(t.milliseconds / 1000), '%i') AS minuti
from track t
join album alb on alb.AlbumId=t.AlbumId
join artist art on art.ArtistId=alb.AlbumId
where TIME_FORMAT(SEC_TO_TIME(t.milliseconds / 1000), '%i') > 6.0
order by art.name;

-- Individuate la durata media delle tracce per ogni genere.

select g.name as genere, avg(TIME_FORMAT(SEC_TO_TIME(t.milliseconds / 1000), '%i')) as durata_media
from track t
join genre g
on g.GenreId=t.GenreId
group by genere
order by durata_media;

-- Elencate tutte le canzoni con la parola “Love” nel titolo, 
-- ordinandole alfabeticamente prima per genere e poi per nome.

select t.name as canzone, g.name as genere
from track t
join genre g
on g.genreid=t.GenreId
where t.name like "%Love%"
group by canzone, genere
order by genere asc, canzone asc;

-- trovate il costo medio per ogni tipologia di media



select m.name as tipo_media, avg(i.total) as costo_medio
from mediatype m
join track t
on t.MediaTypeId = m.MediaTypeId
join invoiceline il
on il.TrackId = t.TrackId
join invoice i
on i.InvoiceId=il.InvoiceId
group by tipo_media;

-- Individuate il genere con più tracce.

select g.name as genere, count(t.trackid) as count
from track t
join genre g
on g.genreid = t.genreid
group by genere
order by count desc
limit 1;

-- Trovate gli artisti che hanno lo stesso numero di album dei Rolling Stones.

select art.name as artista, count(alb.albumid) as n_album
from artist art
join album alb
on alb.ArtistId=art.ArtistId
where art.name = 'Rolling Stones'
group by artista; -- non abbiamo i rolling stones nel database quindi possiamo scrivere:

select art.name as artista, count(alb.albumid) as n_album
from artist art
join album alb
on alb.ArtistId=art.ArtistId
group by artista
having n_album = 0;

--  Trovate l’artista con l’album più costoso.

select * from invoiceline;

select art.name as artista, alb.title as album, sum(i.total) as prezzo_tot
from album alb
join track t
on t.albumid = alb.albumid
join artist art
on art.artistid = alb.artistid
join invoiceline il
on il.trackid = t.trackid
join invoice i
on i.invoiceid =il.invoiceid
group by artista, album
order by prezzo_tot desc
limit 1;