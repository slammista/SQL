-- Identificate tutti i clienti che non hanno effettuato nessun noleggio a gennaio 2006.
select * from rental


SELECT DISTINCT(concat(customer.first_name, " ", customer.last_name)) AS Customer 
FROM customer LEFT JOIN rental ON customer.customer_id = rental.customer_id 
WHERE rental.rental_date NOT BETWEEN 2006/01/01 AND 2006/31/01;

-- Elencate tutti i film che sono stati noleggiati più di 10 volte nell’ultimo quarto del 2005

SELECT 
    f.film_id, f.title, COUNT(*)
FROM
    film AS f
        JOIN
    inventory AS i ON f.film_id = i.film_id
        JOIN
    rental AS r ON i.inventory_id = r.inventory_id
WHERE
    YEAR(r.rental_date) = 2005
        AND QUARTER(r.rental_date) = 3
GROUP BY f.film_id , f.title
	having count(*) > 10;
    
    
-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006.

SELECT DISTINCT
    COUNT(rental_id)
FROM
    rental
WHERE
    DAY(rental_date) = '2006-01-01';

-- Calcolate la somma degli incassi generati nei weekend (sabato e domenica).

select * from payment

SELECT 
    SUM(amount) AS total_weekend_revenue
FROM
    payment
WHERE
    DAYOFWEEK(payment_date) IN (1 , 7);

-- Individuate il cliente che ha speso di più in noleggi.

SELECT 
    c.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS nome,
    SUM(p.amount) AS totale_speso
FROM
    customer AS c
        JOIN
    payment AS p ON c.customer_id = p.customer_id
GROUP BY c.customer_id
ORDER BY totale_speso DESC
LIMIT 1;

-- Elencate i 5 film con la maggiore durata media di noleggio.

select f.film_id, f.title, SEC_TO_TIME(AVG(DATEDIFF(r.return_date, r.rental_date)) * 86400) AS avg_rental_duration 
from film as f
join inventory as i
on f.film_id=i.film_id
join rental as r
on i.inventory_id=r.inventory_id
group by f.film_id
order by avg_rental_duration desc
limit 5;


-- Calcolate il tempo medio tra due noleggi consecutivi da parte di un cliente.

select c.customer_id, concat(c.first_name, " ", c.last_name) as Nome, avg(timestampdiff(day, r.rental_date, r.return_date)) as diff_tempo_noleggi
from customer as c
join rental as r
on c.customer_id = r.customer_id
left join rental as next_rental
on r.customer_id = next_rental.customer_id
and r.rental_date < next_rental.rental_date
group by c.customer_id
order by diff_tempo_noleggi desc;

-- Individuate il numero di noleggi per ogni mese del 2005.

select year(rental_date) as anno, month(rental_date) as mese, count(*)
from rental
where year(rental_date) = 2005
group by anno, mese
order by anno, mese;

-- Trovate i film che sono stati noleggiati almeno due volte lo stesso giorno.

SELECT f.title, COUNT(*) AS n_noleggi
FROM film as f
join inventory as i on f.film_id=i.film_id
join rental as r on i.inventory_id=r.inventory_id
GROUP BY f.film_id, r.rental_date
HAVING COUNT(*) >= 2
ORDER BY n_noleggi DESC;


-- Calcolate il tempo medio di noleggio.

select avg(timestampdiff(second, rental_date, return_date)) as media_noleggio
from rental





