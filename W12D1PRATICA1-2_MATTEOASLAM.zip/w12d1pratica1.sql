-- Effettuate un’esplorazione preliminare del database. Di cosa si tratta?
-- Quante e quali tabelle contiene? 
-- Fate in modo di avere un’idea abbastanza chiara riguardo a con cosa state lavorando.
use sakila;


SELECT table_name FROM information_schema.tables WHERE table_schema = 'sakila';

-- Scoprite quanti clienti si sono registrati nel 2006.

select distinct count(customer_id) as registrati2006
from customer
where create_date between '2006-01-01' and '2006-12-31';

select count(customer_id) as registrati2006
from customer
where year(create_date) = '2006';

-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006.

select * from rental;

select distinct count(rental_id)
from rental
where day(rental_date) = '2006-01-01';

-- Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente
-- che li ha noleggiati.
select * from customer;
select * from rental;
select * from inventory;
select * from film;



select f.film_id, f.title, c.first_name, c.last_name
from rental r
join inventory i on i.inventory_id =r.inventory_id
join film f on f.film_id = i.film_id
join customer c on c.customer_id = r.customer_id
where r.rental_date >= (select date_sub(MAX(rental_date),interval 1 week) from rental);

-- calcolare la durata media del noleggio per ogni categoria di film
select * from film;


select round(avg(f.rental_duration)) as durata_media_noleggio, c.name as genere from category c
join film_category fc on fc.category_id = c.category_id
join film f on f.film_id = fc.film_id
group by c.name;

SELECT c.name AS category, SEC_TO_TIME(AVG(DATEDIFF(r.return_date, r.rental_date)) * 86400) AS avg_rental_duration 
FROM category c 
JOIN film_category fc 
USING(category_id) 
JOIN film f 
USING(film_id) 
JOIN inventory i 
USING(film_id) 
JOIN rental r 
USING(inventory_id) 
GROUP BY c.name;


-- trovare la durata del noleggio più lungo

select max(datediff(r.return_date, r.rental_date)) as durata_noleggio
from rental r;








