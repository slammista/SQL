-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: videogamestoredb
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `videogioco`
--

DROP TABLE IF EXISTS `videogioco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videogioco` (
  `idvideogioco` int NOT NULL,
  `titolo` varchar(50) DEFAULT NULL,
  `sviluppatore` varchar(50) DEFAULT NULL,
  `annodistribuzione` date DEFAULT NULL,
  `costoacquisto` float DEFAULT NULL,
  `genere` varchar(30) DEFAULT NULL,
  `remakedi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idvideogioco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videogioco`
--

LOCK TABLES `videogioco` WRITE;
/*!40000 ALTER TABLE `videogioco` DISABLE KEYS */;
INSERT INTO `videogioco` VALUES (1,'Fifa 2023','EA Sports','2023-01-01',49.99,'Calcio',NULL),(2,'Assassin\'s Creed: Valhalla','Ubisoft','2020-01-01',59.99,'Action',NULL),(3,'Super Mario Odyssey','Nintendo','2017-01-01',39.99,'Platform',NULL),(4,'The Last of Us Part II','Naughty Dog','2020-01-01',69.99,'Action',NULL),(5,'Cyberpunk 2077','CD Projekt Red','2020-01-01',49.99,'RPG',NULL),(6,'Animal Crossing: New Horizons','Nintendo','2020-01-01',54.99,'Simulation',NULL),(7,'Call of Duty: Warzone','Infinity Ward','2020-01-01',0,'FPS',NULL),(8,'The Legend of Zelda: Breath of the Wild','Nintendo','2017-01-01',59.99,'Action-Adventure',NULL),(9,'Fortnite','Epic Games','2017-01-01',0,'Battle Royale',NULL),(10,'Red Dead Redemption','Rockstar','2018-01-01',39.99,'Action-Adventure',NULL);
/*!40000 ALTER TABLE `videogioco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-09 20:40:03
